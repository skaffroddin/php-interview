<?php

include "connection.php";
try {
    $sql = "SELECT * FROM students";
    $query = $con->query($sql);
    $result = $query->fetch_all(MYSQLI_ASSOC);

    $output = "";

    if (count($result) > 0) {
        foreach ($result as $row) {
            $output .= "
                <tr>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['gender']}</td>
                    <td>{$row['degree']}</td>
                    <td>{$row['skills']}</td>
                    <td><img src='{$row['image']}' height='100px' width='100px'/></td>
                    <td><button id='edit' data-id={$row['id']}>Edit</button> | <button id='delete' data-id={$row['id']}>Delete</button></td>
                </tr>
            ";
        }

        echo $output;
    }
} catch (Exception $err) {
    echo $err->getMessage();
}