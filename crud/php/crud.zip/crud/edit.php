<?php

include "connection.php";

try {
    $id = $_REQUEST['id'];
    $sql = "SELECT * FROM `students` WHERE `id`='$id'";
    $query = $con->query($sql);
    $result = $query->fetch_all(MYSQLI_ASSOC);

    $output = '';

    if (count($result) > 0) {
        foreach ($result as $row) {
            $skills = explode(',', $row['skills']);
            $gender = $row['gender'];
            $degree = $row['degree'];

            $output .= "
                <input id='id' type='hidden' value='{$row['id']}'/>
                <input type='text' id='name' value='{$row['name']}'/>
                <input type='text' id='email' value='{$row['email']}'/>
                <input type='text' id='phone' value='{$row['phone']}'/>
                <label><b>Gender:</b></label><br>
                Male: <input type='radio' name='gender' id='male' value='Male' ".($gender == 'Male' ? 'checked' : '')."/>
                Female: <input type='radio' name='gender' id='female' value='Female' ".($gender == 'Female' ? 'checked' : '')."/><br>
                <label><b>Degree:</b></label><br>
                <select id='degree'>
                    <option value=''>Select your degree</option>
                    <option value='BCA' ".($degree == 'BCA' ? 'selected' : '').">BCA</option>
                    <option value='MCA' ".($degree == 'MCA' ? 'selected' : '').">MCA</option>
                    <option value='BBA' ".($degree == 'BBA' ? 'selected' : '').">BBA</option>
                    <option value='MBA' ".($degree == 'MBA' ? 'selected' : '').">MBA</option>
                </select><br>
                <label><b>Skills:</b></label><br>
                <input type='checkbox' name='skills[]' value='Python' ".(in_array('Python', $skills) ? 'checked' : '')."/> Python
                <input type='checkbox' name='skills[]' value='JAVA' ".(in_array('JAVA', $skills) ? 'checked' : '')."/> JAVA
                <input type='checkbox' name='skills[]' value='Javascript' ".(in_array('Javascript', $skills) ? 'checked' : '')."/> Javascript<br>
                <input type='file' id='image'/><br>
                <button id='update'>Update</button>
            ";
        }
        echo $output;
    }
} catch (Exception $e) {
    echo $e->getMessage();
}
?>
