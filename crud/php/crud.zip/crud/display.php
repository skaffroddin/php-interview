<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<table border="1">
    <thead>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Gender</th>
        <th>Degree</th>
        <th>Skills</th>
        <th>Image</th>
        <th>Action</th>
    </thead>
    <tbody id="data">

    </tbody>
</table>
<div id="modal">
    <div id="modal-content">
        <span id="close">X</span>
        <h3>Edit Form</h3>
        <form id="e-form" enctype="multipart/form-data">
        </form>
    </div>
</div>
<style>
    #modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1;
        background-color: rgb(0, 0, 0);
        background-color: rgba(0, 0, 0, 0.4);
        width: 100%;
        height: 100%;
        overflow: auto;
        padding-top: 150px;
        padding-left: 50px;
    }

    #modal-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 40%;
        border-radius: 8px;
    }

    #close {
        float: right;
        background-color: red;
        padding: 5px;
        border-radius: 3px;
        cursor: pointer;
    }

    h3 {
        text-align: center;
    }
</style>


<script>
    $(function(){
        function load(){
            $.ajax({
                url:"loadData.php",
                type:"GET",
                success:function(data){
                    $('#data').html(data)
                },
                error:function(xhr,status,err){
                    console.error("AJAX Error",err);
                    console.log("Error",xhr.responseText);
                    
                }
            })
        }
        load()

        $(document).on('click', '#close', function() {
            $('#modal').hide()
        })

        $(document).on('click','#edit',function(e){
            e.preventDefault()

            $('#modal').show()

                let id = $(this).data('id')

                $.ajax({
                    url: "edit.php",
                    method: "GET",
                    data: {
                        id: id
                    },
                    success: function(data) {
                        $('#e-form').html(data)
                    },
                    error: function(xhr, status, err) {
                        console.error("Ajax Error", err);
                        console.log('ResponseText', xhr.responseText);
                    }
                })

        })


        $(document).on('click', '#update', function(e) {
    e.preventDefault();

    var form = new FormData();
    form.append('id', $('#id').val());
    form.append('name', $('#name').val());
    form.append('email', $('#email').val());
    form.append('phone', $('#phone').val());

    // Gender (radio button value)
    var gender = $('input[name="gender"]:checked').val();
    form.append('gender', gender);

    // Degree (select box value)
    form.append('degree', $('#degree').val());

    // Skills (checkboxes values)
    var skills = [];
    $("input[name='skills[]']:checked").each(function() {
        skills.push($(this).val());
    });
    form.append('skills', skills); // sending as array

    // Image file (if selected)
    var image = $('#image')[0].files[0];
    if (image) {
        form.append('image', image);
    }

    $.ajax({
        url: "editaction.php",
        type: "POST",
        data: form,
        processData: false,
        contentType: false,
        dataType: "json",
        success: function(data) {
            if (data.status === 1) {
                $('#output').text(data.message).css('color', 'green');
                load(); // your function to reload data
                $('#modal').hide(); // hide modal if using
            } else {
                $('#output').text(data.message).css('color', 'red');
            }
        },
        error: function(xhr, status, error) {
            console.error("Ajax error", error);
            console.log("ResponseText", xhr.responseText);
            $('#output').text('An error occurred.').css('color', 'red');
        }
    });
});



    })
</script>