<?php
include "connection.php";

try {
    header("Content-Type: application/json");

    // Fetching values
    $id = $_REQUEST['id'];
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $phone = $_REQUEST['phone'];
    $gender = $_REQUEST['gender'];
    $degree = $_REQUEST['degree'];

    // Skills handling
    if (isset($_REQUEST['skills'])) {
        if (is_array($_REQUEST['skills'])) {
            $skills = implode(',', $_REQUEST['skills']);
        } else {
            $skills = $_REQUEST['skills'];
        }
    } else {
        $skills = '';
    }

    // Image handling
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $imageName = $_FILES['image']['name'];
        $tmpName = $_FILES['image']['tmp_name'];
        $uploadPath = "uploads/" . $imageName;
        move_uploaded_file($tmpName, $uploadPath);
    } else {
        $uploadPath = null;
    }

    // Building SQL
    $sql = "UPDATE `students` SET 
                `name` = '$name',
                `email` = '$email',
                `phone` = '$phone',
                `gender` = '$gender',
                `degree` = '$degree',
                `skills` = '$skills'";

    if ($uploadPath) {
        $sql .= ", `image` = '$uploadPath'";
    }

    $sql .= " WHERE `id` = '$id'";

    $query = $con->query($sql);

    if ($query) {
        echo json_encode(['status' => 1, 'message' => 'Data updated successfully.']);
    } else {
        echo json_encode(['status' => 0, 'message' => 'Failed to update data.']);
    }
    
} catch (Exception $err) {
    echo json_encode(['status' => 0, 'message' => $err->getMessage()]);
}
?>
