<?php


try {
    $con = new mysqli("localhost","root","","college");
    // echo "OK";
} catch (Exception $err) {
    echo $err->getMessage();
}