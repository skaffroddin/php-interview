<?php
include "connection.php";
header("Content-Type:application/json");
$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$phone = $_REQUEST['phone'];
$gen = $_REQUEST['gen'];
$degree = $_REQUEST['degree'];
$skills = is_array($_REQUEST['skills']) ? implode($_REQUEST['skills']) : $_REQUEST['skills'];
$imageName = $_FILES['image']['name'];
$tmpName = $_FILES['image']['tmp_name'];
$upload = "uploads/" . $imageName;
move_uploaded_file($tmpName,$upload);

$sql = "INSERT INTO `students`( `name`, `email`, `phone`, `gender`, `degree`, `skills`, `image`) VALUES (?,?,?,?,?,?,?)";

$query = $con->prepare($sql);
$query->bind_param("sssssss",$name,$email,$phone,$gen,$degree,$skills,$upload);

if ($query->execute()) {
    echo json_encode(['status'=>1,'message'=>'Data inserted']);
}