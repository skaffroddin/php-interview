<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body>
    <form action="" method="post" enctype="multipart/form-data">
        Name : <input type="text" name="" id="name"><br>
        Email : <input type="text" name="" id="email"><br>
        Phone : <input type="text" name="" id="phone"><br>
        <label for="gen">Gender</label><br>
        Male : <input type="radio" name="" id="gen" value="Male">
        Female : <input type="radio" name="" id="gen" value="Female"><br>
        <select name="" id="degree">
            <option>Select your degree</option>
            <option value="BCA">BCA</option>
            <option value="MCA">MCA</option>
            <option value="BBA">BBA</option>
            <option value="MBA">MBA</option>
        </select><br>
        <label for="skills"><b>Skills</b></label><br>
        Python : <input type="checkbox" name="skills[]" id="skills" value="Python">
        JAVA : <input type="checkbox" name="skills[]" id="skills" value="JAVA">
        Javascript : <input type="checkbox" name="skills[]" id="skills" value="Javascript"><br>
        <input type="file" name="" id="image"><br>
        <button id="submit">Submit</button>
    </form>
    <div id="output"></div>
    <script>
        $(function() {
            $('#submit').click(function(e) {
                e.preventDefault()

                var form = new FormData()

                var name = $('#name').val().trim();
                var email = $('#email').val().trim();
                var phone = $('#phone').val().trim();

                var nameRegex = /^[a-zA-Z\s]+$/;
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                var phoneRegex = /^[0-9]{10}$/;

                if (name == '' || !nameRegex.test(name)) {
                    $('#output').text('Please enter a valid name (letters and spaces only).');
                    return;
                }

                if (email == '' || !emailRegex.test(email)) {
                    $('#output').text('Please enter a valid email address.');
                    return;
                }

                if (phone == '' || !phoneRegex.test(phone)) {
                    $('#output').text('Please enter a valid 10-digit phone number.');
                    return;
                }

                form.append('name', $('#name').val())
                form.append('email', $('#email').val())
                form.append('phone', $('#phone').val())
                form.append('gen', $('#gen').val())
                form.append('degree', $('#degree').val())

                var skills = []

                $.each($('input[name="skills[]"]:checked'), function() {
                    skills.push($(this).val())
                })

                form.append('skills', skills.join(','))
                form.append('image', $('#image')[0].files[0])

                $.ajax({
                    url: "formaction.php",
                    method: "POST",
                    data: form,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function(res) {
                        if (res.status == 1) {
                            $('#output').text(res.message)
                        }
                    },
                    error: function(xhr, status, err) {
                        console.error("AJAX Error", err);
                        console.log("Error", xhr.responseText);
                    }
                })
            })
        })
    </script>
</body>

</html>